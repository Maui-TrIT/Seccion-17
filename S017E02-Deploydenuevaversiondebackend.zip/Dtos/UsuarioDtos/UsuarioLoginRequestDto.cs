namespace NetKubernetes.Dtos.UsuarioDtos;

public class UsuarioLoginRequestDto {

    public string? Email { get; set; }

    public string? Password { get; set; }

}