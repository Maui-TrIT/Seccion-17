namespace NetKubernetes.Dtos.CompraDtos;

public class CompraRequestDto {

    public IEnumerable<CompraItemRequestDto>? Data { get; set; } 
}