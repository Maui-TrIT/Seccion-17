namespace NetKubernetes.Dtos.BookmarkDtos;

public class BookmarkRequestDto
{
    public int InmuebleId {get;set;}
    public string? UsuarioId {get;set;}
}